data class NewsItem(
    val title: String,
    val source: String,
    val date: String,
    val imageRes: Int
)