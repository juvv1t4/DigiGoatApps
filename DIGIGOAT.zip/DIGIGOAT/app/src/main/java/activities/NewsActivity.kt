import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hero.digigoat.R

class NewsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewsBinding
    private lateinit var newsAdapter: NewsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViews()
        loadNews()
    }

    private fun setupViews() {
        // Setup RecyclerView
        newsAdapter = NewsAdapter()
        binding.newsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@NewsActivity)
            adapter = newsAdapter
        }

        // Setup TabLayout
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when(tab?.position) {
                    0 -> loadNews()
                    1 -> loadMarketPrices()
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        // Setup Search
        binding.searchEdit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterNews(s.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Setup Bottom Navigation
        binding.bottomNav.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // Handle home click
                    true
                }
                R.id.nav_management -> {
                    // Handle management click
                    true
                }
                R.id.nav_news -> {
                    // Already on news
                    true
                }
                R.id.nav_profile -> {
                    // Handle profile click
                    true
                }
                else -> false
            }
        }
    }

    private fun loadNews() {
        // Sample news data
        val newsList = listOf(
            NewsItem(
                "Pentingnya Nutrisi yang Seimbang Pada Kambing",
                "BBC News",
                "Jun 9, 2023",
                R.drawable.news1
            ),
            NewsItem(
                "Perawatan Kambing di Musim Hujan",
                "Reuters",
                "Jun 8, 2023",
                R.drawable.news2
            ),
            NewsItem(
                "Manfaat Suplemen Vitamin untuk Produktivitas Kambing",
                "The NYT",
                "Jun 6, 2023",
                R.drawable.news3
            ),
            NewsItem(
                "Nutrisi Tepat, Kunci Sukses Peternakan Kambing",
                "Local News",
                "Jun 5, 2023",
                R.drawable.news4
            )
        )
        newsAdapter.submitList(newsList)
    }

    private fun filterNews(query: String) {
        // Implement news filtering logic
    }

    private fun loadMarketPrices() {
        // Implement market prices loading logic
    }
}